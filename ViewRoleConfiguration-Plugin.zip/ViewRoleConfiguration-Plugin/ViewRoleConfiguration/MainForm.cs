﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Xrm.Sdk.Query;
using XrmToolBox.Extensibility;
namespace ViewRoleConfiguration
{
    public partial class MainForm : PluginControlBase
    {
        #region varibale used
        List<SecurityRole> userRoles;
        List<MyEntity> MyEntitys;
        bool validate;
        #endregion
        #region constructor
        public MainForm()
        {
            InitializeComponent();
           
        }
        #endregion
        #region Import Solution
        private void btn_impSol_Click(object sender, EventArgs e)
        {
            WorkAsync(new WorkAsyncInfo
            {
                Message = "Importing Solution...",
                Work = (bw, m) =>
                {

                    Helper.createConn(Service);
                    if (Service != null)
                    {
                        Helper.MyMessage = string.Empty;
                        Helper.importSolution();
                        if (!string.IsNullOrEmpty(Helper.MyMessage))
                        {
                            MessageBox.Show(Helper.MyMessage);
                        }

                    }
                },
                PostWorkCallBack = m =>
                {
                    if (m.Error == null)
                    {

                    }
                    else
                    {
                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            });

         
        }
        #endregion
        #region Reterieve Data
        private void btn_retdata_Click(object sender, EventArgs e)
        {
            WorkAsync(new WorkAsyncInfo
            {
                Message = "Validating Solution...",
                Work = (bw, m) =>
                {

                    Helper.createConn(Service);
                    if (Service != null)
                    {
                       validate= Helper.ValidateSolutions("ViewRoleConfiguration");

                    }
                },
                PostWorkCallBack = m =>
                {
                    if (m.Error == null)
                    {
                        if (!validate)
                        retrievesecurityRole();
                        else
                            MessageBox.Show("Required Solution not found. Click on Import Solution first.");
                    }
                    else
                    {
                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            });
        }
        private void retrievesecurityRole()
        {
            drp_sRole.DataSource = null;
            drp_sRole.Items.Clear();
            WorkAsync(new WorkAsyncInfo
            {
                Message = "Reterieving Security Role...",
                Work = (bw, m) =>
                {

                    Helper.createConn(Service);
                    if (Service != null)
                    {
                        //Set security drop down
                        userRoles = Helper.getSecurityRole();
                        userRoles.Sort((p, q) => p.Name.CompareTo(q.Name));
                        SecurityRole SelectRole = new SecurityRole();
                        SelectRole.Name = "--Select--";
                        SelectRole.RoldId = Guid.Empty;
                        userRoles.Insert(0, SelectRole);
                    }
                },
                PostWorkCallBack = m =>
                {
                    if (m.Error == null)
                    {
                        drp_sRole.DataSource = userRoles;
                        drp_sRole.DisplayMember = "Name";
                        drp_sRole.ValueMember = "RoldId";
                        retrieveViewConfig();
                    }
                    else
                    {
                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            });
        }
        private void retrieveViewConfig()
        {
            drp_entities.DataSource = null;
            drp_entities.Items.Clear();
            WorkAsync(new WorkAsyncInfo
            {
                Message = "Reterieving Entity List...",
                Work = (bw, m) =>
                {

                    Helper.createConn(Service);
                    if (Service != null)
                    {
                        //Set entity drop down
                        MyEntitys = Helper.getEntities();
                        MyEntitys.Sort((p, q) => p.DisplayName.CompareTo(q.DisplayName));
                        MyEntity Select = new MyEntity();
                        Select.DisplayName = "--Select--";
                        Select.EntityId = Guid.Empty;
                        MyEntitys.Insert(0, Select);
                    }
                },
                PostWorkCallBack = m =>
                {
                    if (m.Error == null)
                    {
                        drp_entities.DataSource = MyEntitys;
                        drp_entities.DisplayMember = "DisplayName";
                        drp_entities.ValueMember = "EntityId";
                        //Clear grid view
                        grdview_Views.DataSource = null;
                        textBox1.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            });
        }
        #endregion
        #region Entity index change
        private void drp_entities_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                WorkAsync(new WorkAsyncInfo
                {
                    Message = "Reterieving View Information...",
                    Work = (bw, m) =>
                    {

                        Helper.createConn(Service);
                        if (Service != null)
                        {
                            bool flag = this.drp_entities.SelectedIndex > 0;
                            bool flag1 = this.drp_sRole.SelectedIndex > 0;
                            if (flag & flag1)
                            {
                                MyEntity enity = (MyEntity)drp_entities.SelectedItem;
                                SecurityRole Role = (SecurityRole)drp_sRole.SelectedItem;
                                Helper.getViewbyentity(enity.ObjectTypeCode);//Helper.MyViews
                                Helper.getViewConfig(enity.ObjectTypeCode, Role.RoldId);//Helper.ViewConfigColl
                                Helper.IsUpdate = false;
                                foreach (ViewConfig viecon in Helper.ViewConfigColl)
                                {
                                    IEnumerable<View> filteredMyViews = Helper.MyViews.Where(o => viecon.Hiddenviews.Contains(o.ViewId.ToString()));
                                    foreach (View vv in filteredMyViews)
                                    {
                                        vv.Visible = true;
                                        Helper.IsUpdate = true;
                                        Helper.ViewroleconfigurationId = viecon.ViewroleconfigurationId;
                                    }
                                }
                                grdview_Views.DataSource = Helper.MyViews;
                                grdview_Views.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                                grdview_Views.Columns[0].Visible = false;
                                grdview_Views.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;

                            }

                        }
                    },
                    PostWorkCallBack = m =>
                    {
                        if (m.Error == null)
                        {

                        }
                        else
                        {
                            MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                            MessageBoxIcon.Error);
                        }
                    }
                });
               
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
        #endregion
        #region search textbox
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
                grdview_Views.DataSource = Helper.MyViews.Where(x => x.ViewName.ToLower().Contains(textBox1.Text.ToLower())).ToList();
            else
                grdview_Views.DataSource = Helper.MyViews;
        }
        #endregion
        #region Close click
        private void btn_close_Click(object sender, EventArgs e)
        {
            base.CloseTool();
        }
        #endregion
        #region Save all data
        private void btn_saveall_Click(object sender, EventArgs e)
        {
            WorkAsync(new WorkAsyncInfo
            {
                Message = "Saving view configuration...",
                Work = (bw, m) =>
                {

                    Helper.createConn(Service);
                    if (Service != null)
                    {

                        string hideView = string.Empty;
                        foreach (DataGridViewRow row in grdview_Views.Rows)
                        {
                            if (row.Cells[2].ValueType == typeof(bool))
                            {
                                if ((bool)row.Cells[2].Value == true)
                                {
                                    hideView += ";" + row.Cells[0].Value.ToString();

                                }
                            }

                        }
                        if (!String.IsNullOrEmpty(hideView))
                        {
                            Entity ent = new Entity("sav_viewroleconfiguration");
                            ent.Attributes["sav_name"] = ((SecurityRole)drp_sRole.SelectedItem).Name;
                            ent.Attributes["sav_entitylogicalname"] = ((MyEntity)drp_entities.SelectedItem).LogicalName;
                            ent.Attributes["sav_entitytypecode"] = ((MyEntity)drp_entities.SelectedItem).ObjectTypeCode.ToString();
                            ent.Attributes["sav_hiddenviews"] = hideView.TrimStart(';');
                            ent.Attributes["sav_securityrole"] = new EntityReference("role", ((SecurityRole)drp_sRole.SelectedItem).RoldId);
                            if (Helper.IsUpdate)
                                ent.Id = Helper.ViewroleconfigurationId;
                            Helper.MyMessage = string.Empty;
                            Helper.saveData(ent);
                            if (!string.IsNullOrEmpty(Helper.MyMessage))
                                MessageBox.Show(Helper.MyMessage);
                            else
                                MessageBox.Show("Data saved successfully!!");
                        }
                        else
                            if (Helper.IsUpdate)
                            {
                                Helper.DeleteRecord("sav_viewroleconfiguration", Helper.ViewroleconfigurationId);
                                MessageBox.Show("Record Deleted!!");
                            }
                            else
                                MessageBox.Show("No row selected !!"); 

                    }
                },
                PostWorkCallBack = m =>
                {
                    if (m.Error == null)
                    {
                        drp_entities.SelectedIndex = 0;
                        drp_sRole.SelectedIndex = 0;
                        grdview_Views.DataSource = null;
                        textBox1.Text = string.Empty;
                    }
                    else
                    {
                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            });

        }
        #endregion
        #region Select view
        private void grdview_Views_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            foreach (DataGridViewRow row in grdview_Views.SelectedRows)
            {
                if (row.Cells[2].ValueType == typeof(bool))
                {
                    if ((bool)row.Cells[2].Value == false)
                    {
                        row.Cells[2].Value = true;
                        View View = Helper.MyViews.Where(x => x.ViewId.Equals(row.Cells[0].Value)).First();
                        View.Visible = true;

                    }
                    else
                    {
                        row.Cells[2].Value = !(bool)row.Cells[2].Value;
                        View View = Helper.MyViews.Where(x => x.ViewId.Equals(row.Cells[0].Value)).First();
                        View.Visible = false;
                    }
                }
            }
        }
        #endregion
        #region Security role change
        private void drp_sRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            drp_entities_SelectedIndexChanged(null, null);
        }
        #endregion

        private void btn_remSol_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do you want to delete ViewRoleConfiguration solution?", "Confirm Box", MessageBoxButtons.YesNoCancel, 
        MessageBoxIcon.Information);

    if (dr == DialogResult.Yes)
    {
         WorkAsync(new WorkAsyncInfo
            {
                Message = "Deleting Solution...",
                Work = (bw, m) =>
                {
                    Helper.createConn(Service);
                    if (Service != null)
                    {
                        Helper.MyMessage = string.Empty;
                        Helper.deleteSolution();
                        if (!string.IsNullOrEmpty(Helper.MyMessage))
                        {
                            MessageBox.Show(Helper.MyMessage);
                        }

                    }
                },
                PostWorkCallBack = m =>
                {
                    if (m.Error == null)
                    {

                    }
                    else
                    {
                        MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                    }
                }
            });
    }
           

        }
    }
}
