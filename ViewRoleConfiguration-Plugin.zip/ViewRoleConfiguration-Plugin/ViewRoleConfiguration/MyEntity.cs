﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewRoleConfiguration
{
    internal class MyEntity
    {
        private string _logicalName;

        public string LogicalName
        {
            get { return _logicalName; }
            set { _logicalName = value; }
        }
        private string _displayName;

        public string DisplayName
        {
            get { return _displayName; }
            set { _displayName = value; }
        }
        private Guid _entityId;

        public Guid EntityId
        {
            get { return _entityId; }
            set { _entityId = value; }
        }

        private string _schemaName;

        public string SchemaName
        {
            get { return _schemaName; }
            set { _schemaName = value; }
        }
        private bool _IsActivity;

        public bool IsActivity
        {
            get { return _IsActivity; }
            set { _IsActivity = value; }
        }
        private int _ObjectTypeCode;

        public int ObjectTypeCode
        {
            get { return _ObjectTypeCode; }
            set { _ObjectTypeCode = value; }
        }
    }
}
