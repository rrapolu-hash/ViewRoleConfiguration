﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.IO;
using System.Xml;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.Drawing;
using Microsoft.Xrm.Tooling.Connector;
using System.Net;
using System.Windows.Forms;

namespace ViewRoleConfiguration
{
    public static class Helper
    {
        #region variable used
        private static string _myMessage;

        public static string MyMessage
        {
            get { return Helper._myMessage; }
            set { Helper._myMessage = value; }
        }
        private static List<MyEntity> _myEntities;

        internal static List<MyEntity> MyEntities
        {
            get { return Helper._myEntities; }
            set { Helper._myEntities = value; }
        }
        private static List<SecurityRole> _securityRoles;
        internal static List<SecurityRole> SecurityRoles
        {
            get { return Helper._securityRoles; }
            set { Helper._securityRoles = value; }
        }
        private static List<View> _myviews;

        internal static List<View> MyViews
        {
            get { return Helper._myviews; }
            set { Helper._myviews = value; }
        }

        private static List<ViewConfig> _viewConfigColl;

        internal static List<ViewConfig> ViewConfigColl
        {
            get { return Helper._viewConfigColl; }
            set { Helper._viewConfigColl = value; }
        }
        private static bool _isUpdate;

        public static bool IsUpdate
        {
            get { return Helper._isUpdate; }
            set { Helper._isUpdate = value; }
        }
        private static Guid _viewroleconfigurationId;

        public static Guid ViewroleconfigurationId
        {
            get { return _viewroleconfigurationId; }
            set { _viewroleconfigurationId = value; }
        }
        private static OrganizationServiceProxy _serviceProxy;
        public static OrganizationServiceProxy ServiceProxy
        {
            get { return Helper._serviceProxy; }
            set { Helper._serviceProxy = value; }
        }
        private static string _OrganizationUri;
        public static string OrganizationUri
        {
            get { return Helper._OrganizationUri; }
            set { Helper._OrganizationUri = value; }
        }
        private static ClientCredentials _Credentials = null;
        public static ClientCredentials Credentials
        {
            get { return Helper._Credentials; }
            set { Helper._Credentials = value; }
        }
        #endregion
        #region create Connection
        internal static void createConn(IOrganizationService Service)
        {

            _serviceProxy = (OrganizationServiceProxy)Service;

        }
        #endregion
        private static Entity _solution;

        public static Entity Solution
        {
            get { return _solution; }
            set { _solution = value; }
        }
        #region ValidateSolutions
        internal static bool ValidateSolutions(string newSolution)
        {
            // Retrieve a solution
            QueryExpression querySampleSolution = new QueryExpression
            {

                EntityName = "solution",
                ColumnSet = new ColumnSet(true),
                Criteria = new FilterExpression()
            };

            querySampleSolution.Criteria.AddCondition("uniquename", ConditionOperator.Equal, newSolution);
            EntityCollection coll = _serviceProxy.RetrieveMultiple(querySampleSolution);
            if (coll.Entities.Count > 0)
            {
                Solution = coll.Entities[0];
                return false;
            }
            else
                return true;
        }
        #endregion
        #region importSolution
        internal static void importSolution()
        {

            try
            {
                if (ValidateSolutions("ViewRoleConfiguration"))// Check  solution
                {
                    byte[] manageSolution = Properties.Resources.ViewRoleConfiguration_1_0_0_0_managed;
                    if (manageSolution != null)
                    {
                        // Import  solution
                        ImportSolutionRequest importRequest = new ImportSolutionRequest();
                        importRequest.CustomizationFile = manageSolution;
                        importRequest.PublishWorkflows = true;
                        ImportSolutionResponse importResponse = (ImportSolutionResponse)_serviceProxy.Execute(importRequest);
                        MyMessage = "Solution imported successfully";
                    }
                }
                else
                    MyMessage = "Solution already present";


            }
            catch (Exception ex)
            {
                MyMessage = ex.ToString();

            }

        }
        #endregion
        #region deleteSolution
        internal static void deleteSolution()
        {

            try
            {
                if (!ValidateSolutions("ViewRoleConfiguration"))// Check  solution
                {
                    if (Solution != null)
                    {
                        // Delete  solution
                        _serviceProxy.Timeout = new TimeSpan(0, 5, 0);
                        _serviceProxy.Delete(Solution.LogicalName, Solution.Id);
                        MyMessage = "Solution deleted";
                    }
                }
                else
                    MyMessage = "Solution allready deleted";


            }
            catch (Exception ex)
            {
                MyMessage = ex.ToString();

            }

        }
        #endregion
        #region getSecurityRole
        internal static List<SecurityRole> getSecurityRole()
        {
            EntityCollection returnCollection;
            List<SecurityRole> accessRoles = new List<SecurityRole>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>"
  + "<entity name='role'>"
    + "<attribute name='name' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='roleid' />"
    + "<order attribute='name' descending='false' />"
        + "<filter type='and'>"
          + "<condition attribute='businessunitid' operator='eq-businessid'  />"
        + "</filter>"
  + "</entity>"
+ "</fetch>";
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;
                foreach (Entity ent in returnCollection.Entities)
                {
                    SecurityRole SecurityRole = new SecurityRole();

                    SecurityRole.Name = ent.Attributes["name"].ToString();
                    SecurityRole.BusinessUnit = (EntityReference)ent.Attributes["businessunitid"];
                    SecurityRole.RoldId = ent.Id;
                    accessRoles.Add(SecurityRole);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return accessRoles;
        }
        #endregion
        #region getEntities
        internal static List<MyEntity> getEntities()
        {
            MyEntities = new List<MyEntity>();
            RetrieveAllEntitiesResponse retrieveAllEntitiesResponse = (RetrieveAllEntitiesResponse)_serviceProxy.Execute(new RetrieveAllEntitiesRequest());
            EntityMetadata[] entityMetadata = retrieveAllEntitiesResponse.EntityMetadata;
            foreach (EntityMetadata current in entityMetadata)
            {
                string text = (current.DisplayName != null && current.DisplayName.UserLocalizedLabel != null) ? current.DisplayName.UserLocalizedLabel.Label : "N/A";
                bool flag2 = text != "N/A";
                if (flag2)
                {
                    MyEntity ent = new MyEntity();
                    ent.DisplayName = text;
                    ent.EntityId = (Guid)current.MetadataId;
                    ent.ObjectTypeCode =(int) current.ObjectTypeCode;
                    ent.LogicalName = current.LogicalName;
                    ent.SchemaName = current.SchemaName;
                    ent.IsActivity = (bool)current.IsActivity;
                    MyEntities.Add(ent);
                }
            }



            return MyEntities;
        }
        #endregion
        #region getViewbyentity
        internal static void getViewbyentity(int returnedtypecode)
        {
            try
            {
                MyViews = new List<View>();
                QueryExpression Views = new QueryExpression("savedquery");
                Views.ColumnSet = new ColumnSet(true);
                Views.Criteria.Conditions.Add(new ConditionExpression("returnedtypecode", ConditionOperator.Equal, returnedtypecode));
                Views.Criteria.Conditions.Add(new ConditionExpression("querytype", ConditionOperator.Equal, 0));
                EntityCollection viewCollection = _serviceProxy.RetrieveMultiple(Views);
                foreach (Entity Viewent in viewCollection.Entities)
                {
                    View view = new View();
                    view.ViewId = Viewent.Id;
                    view.ViewName = Viewent.Attributes["name"].ToString();
                    MyViews.Add(view);
                }
               
            }
            catch (Exception ex)
            {
                MyMessage= ex.Message.ToString();
               
            }
        }
        #endregion
        #region saveData
        internal static void saveData(Entity ent )
        {
            try
            {
                if (ent != null)
                {
                    if (IsUpdate)
                        _serviceProxy.Update(ent);
                    else
                        _serviceProxy.Create(ent);

                }
                    

            }
            catch (Exception ex)
            {
                MyMessage = ex.Message.ToString();

            }
        }
        #endregion
        #region Delete Record
        internal static void DeleteRecord(string LogicalName,Guid Id)
        {
            try
            {
                        _serviceProxy.Delete(LogicalName,Id);

            }
            catch (Exception ex)
            {
                MyMessage = ex.Message.ToString();

            }
        }
        #endregion
        #region getViewConfig
        internal static void getViewConfig(int returnedtypecode,Guid  roleID)
        {
            try
            {
                ViewConfigColl = new List<ViewConfig>();
                QueryExpression viewroleconfiguration = new QueryExpression("sav_viewroleconfiguration");
                viewroleconfiguration.ColumnSet = new ColumnSet(true);
                viewroleconfiguration.Criteria.Conditions.Add(new ConditionExpression("sav_entitytypecode", ConditionOperator.Equal, returnedtypecode.ToString()));
                viewroleconfiguration.Criteria.Conditions.Add(new ConditionExpression("sav_securityrole", ConditionOperator.Equal,  roleID));
                EntityCollection viewroleconfigurationCollection = _serviceProxy.RetrieveMultiple(viewroleconfiguration);
                foreach (Entity viewroleconfigurationent in viewroleconfigurationCollection.Entities)
                {
                    ViewConfig view = new ViewConfig();
                    view.ViewroleconfigurationId = viewroleconfigurationent.Id;
                    view.Hiddenviews = viewroleconfigurationent.Attributes["sav_hiddenviews"].ToString().Split(';');
                    view.Securityrole = viewroleconfigurationent.GetAttributeValue<EntityReference>("sav_securityrole");
                    view.Entitytypecode = viewroleconfigurationent.Attributes["sav_entitytypecode"].ToString();
                    view.Entitylogicalname = viewroleconfigurationent.Attributes["sav_entitylogicalname"].ToString();
                    ViewConfigColl.Add(view);
                }

            }
            catch (Exception ex)
            {
                MyMessage = ex.Message.ToString();

            }
        }
        #endregion
        #region Helper Functions
        internal static string CreateXml(string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }
        internal static string CreateXml(XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }
        #endregion
    }
}
