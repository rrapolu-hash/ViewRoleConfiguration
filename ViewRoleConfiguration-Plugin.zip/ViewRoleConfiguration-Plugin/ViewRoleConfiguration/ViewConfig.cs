﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ViewRoleConfiguration
{
    internal class ViewConfig
    {
        private string _entitylogicalname;

        public string Entitylogicalname
        {
            get { return _entitylogicalname; }
            set { _entitylogicalname = value; }
        }
        private string _entitytypecode;

        public string Entitytypecode
        {
            get { return _entitytypecode; }
            set { _entitytypecode = value; }
        }
        private EntityReference _securityrole;

        public EntityReference Securityrole
        {
            get { return _securityrole; }
            set { _securityrole = value; }
        }
        private string[] _hiddenviews;

        public string[] Hiddenviews
        {
            get { return _hiddenviews; }
            set { _hiddenviews = value; }
        }
        private Guid _viewroleconfigurationId;

        public Guid ViewroleconfigurationId
        {
            get { return _viewroleconfigurationId; }
            set { _viewroleconfigurationId = value; }
        }
       


    }
}
