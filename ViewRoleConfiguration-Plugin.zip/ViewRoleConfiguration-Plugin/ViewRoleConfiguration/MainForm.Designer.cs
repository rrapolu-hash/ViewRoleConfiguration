﻿namespace ViewRoleConfiguration
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.drp_entities = new System.Windows.Forms.ComboBox();
            this.lbl_entity = new System.Windows.Forms.Label();
            this.drp_sRole = new System.Windows.Forms.ComboBox();
            this.lbl_sRole = new System.Windows.Forms.Label();
            this.grdview_Views = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lb_Filter = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_close = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_impSol = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_retdata = new System.Windows.Forms.ToolStripButton();
            this.btn_saveall = new System.Windows.Forms.ToolStripButton();
            this.btn_remSol = new System.Windows.Forms.ToolStripButton();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdview_Views)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(0, 28);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1041, 548);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1033, 522);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Information";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.Controls.Add(this.drp_entities);
            this.groupBox1.Controls.Add(this.lbl_entity);
            this.groupBox1.Controls.Add(this.drp_sRole);
            this.groupBox1.Controls.Add(this.lbl_sRole);
            this.groupBox1.Controls.Add(this.grdview_Views);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.lb_Filter);
            this.groupBox1.Location = new System.Drawing.Point(8, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1019, 510);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // drp_entities
            // 
            this.drp_entities.FormattingEnabled = true;
            this.drp_entities.Location = new System.Drawing.Point(427, 20);
            this.drp_entities.Name = "drp_entities";
            this.drp_entities.Size = new System.Drawing.Size(195, 21);
            this.drp_entities.TabIndex = 6;
            this.drp_entities.SelectedIndexChanged += new System.EventHandler(this.drp_entities_SelectedIndexChanged);
            // 
            // lbl_entity
            // 
            this.lbl_entity.AutoSize = true;
            this.lbl_entity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_entity.Location = new System.Drawing.Point(329, 20);
            this.lbl_entity.Name = "lbl_entity";
            this.lbl_entity.Size = new System.Drawing.Size(83, 13);
            this.lbl_entity.TabIndex = 5;
            this.lbl_entity.Text = "Select Entity:";
            // 
            // drp_sRole
            // 
            this.drp_sRole.FormattingEnabled = true;
            this.drp_sRole.Location = new System.Drawing.Point(103, 19);
            this.drp_sRole.Name = "drp_sRole";
            this.drp_sRole.Size = new System.Drawing.Size(195, 21);
            this.drp_sRole.TabIndex = 4;
            this.drp_sRole.SelectedIndexChanged += new System.EventHandler(this.drp_sRole_SelectedIndexChanged);
            // 
            // lbl_sRole
            // 
            this.lbl_sRole.AutoSize = true;
            this.lbl_sRole.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sRole.Location = new System.Drawing.Point(7, 20);
            this.lbl_sRole.Name = "lbl_sRole";
            this.lbl_sRole.Size = new System.Drawing.Size(87, 13);
            this.lbl_sRole.TabIndex = 3;
            this.lbl_sRole.Text = "Security Role:";
            // 
            // grdview_Views
            // 
            this.grdview_Views.AllowUserToAddRows = false;
            this.grdview_Views.AllowUserToDeleteRows = false;
            this.grdview_Views.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grdview_Views.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdview_Views.Location = new System.Drawing.Point(13, 88);
            this.grdview_Views.MultiSelect = false;
            this.grdview_Views.Name = "grdview_Views";
            this.grdview_Views.ReadOnly = true;
            this.grdview_Views.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdview_Views.Size = new System.Drawing.Size(1000, 416);
            this.grdview_Views.TabIndex = 2;
            this.grdview_Views.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.grdview_Views_CellMouseClick);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1.Location = new System.Drawing.Point(103, 62);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(519, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lb_Filter
            // 
            this.lb_Filter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lb_Filter.AutoSize = true;
            this.lb_Filter.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Filter.Location = new System.Drawing.Point(7, 62);
            this.lb_Filter.Name = "lb_Filter";
            this.lb_Filter.Size = new System.Drawing.Size(47, 13);
            this.lb_Filter.TabIndex = 0;
            this.lb_Filter.Text = "Search";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.btn_close,
            this.toolStripSeparator2,
            this.btn_impSol,
            this.toolStripSeparator3,
            this.btn_retdata,
            this.btn_saveall,
            this.btn_remSol});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1053, 25);
            this.toolStrip1.TabIndex = 11;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btn_close
            // 
            this.btn_close.Image = global::ViewRoleConfiguration.Properties.Resources.tsbClose_Image;
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(56, 22);
            this.btn_close.Text = "Close";
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // btn_impSol
            // 
            this.btn_impSol.Image = global::ViewRoleConfiguration.Properties.Resources.tsbConnect_Image;
            this.btn_impSol.Name = "btn_impSol";
            this.btn_impSol.Size = new System.Drawing.Size(110, 22);
            this.btn_impSol.Text = "Import Solution";
            this.btn_impSol.Click += new System.EventHandler(this.btn_impSol_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // btn_retdata
            // 
            this.btn_retdata.Image = global::ViewRoleConfiguration.Properties.Resources.clonesolution;
            this.btn_retdata.Name = "btn_retdata";
            this.btn_retdata.Size = new System.Drawing.Size(96, 22);
            this.btn_retdata.Text = "Retrieve Data";
            this.btn_retdata.Click += new System.EventHandler(this.btn_retdata_Click);
            // 
            // btn_saveall
            // 
            this.btn_saveall.Image = global::ViewRoleConfiguration.Properties.Resources.publishall;
            this.btn_saveall.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_saveall.Name = "btn_saveall";
            this.btn_saveall.Size = new System.Drawing.Size(78, 22);
            this.btn_saveall.Text = "Save Data";
            this.btn_saveall.Click += new System.EventHandler(this.btn_saveall_Click);
            // 
            // btn_remSol
            // 
            this.btn_remSol.Image = global::ViewRoleConfiguration.Properties.Resources.tsbConnect_Image;
            this.btn_remSol.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_remSol.Name = "btn_remSol";
            this.btn_remSol.Size = new System.Drawing.Size(117, 22);
            this.btn_remSol.Text = "Remove Solution";
            this.btn_remSol.Click += new System.EventHandler(this.btn_remSol_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabControl1);
            this.Name = "MainForm";
            this.Size = new System.Drawing.Size(1053, 588);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdview_Views)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lb_Filter;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btn_close;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btn_impSol;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.DataGridView grdview_Views;
        private System.Windows.Forms.ToolStripButton btn_retdata;
        private System.Windows.Forms.ToolStripButton btn_saveall;
        private System.Windows.Forms.ComboBox drp_sRole;
        private System.Windows.Forms.Label lbl_sRole;
        private System.Windows.Forms.ComboBox drp_entities;
        private System.Windows.Forms.Label lbl_entity;
        private System.Windows.Forms.ToolStripButton btn_remSol;
    }
}